# from django.test import TestCase
# from ..models import Task
# from accounts.models import User, Profile


# # Create your tests here.

# class TestTaskView(TestCase):

#     def setUp(self):
#         self.user = User.objects.create(email="test@gmail.com", password="qwe123QWE@")
#         self.profile = Profile.objects.create(
#             user=self.user,
#             first_name = 'test-first-name',
#             last_name = 'test-last-name',
#             description = 'test-tttttttttttttttttt',
#         )
    
#     def test_create_todo_model_with_valid_data(self):
#         task = Task.objects.create(
#             user = self.user,
#             title = "test",
#             description = "this is test",
#             is_done = True
#         )
#         self.assertTrue(Task.objects.filter(pk=task.pk).exists())