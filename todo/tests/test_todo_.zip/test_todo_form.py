# from django.test import TestCase
# from ..views import TaskListView, TaskCreateView
# from ..forms import TaskForm

# # Create your tests here.

# class TestTodoForm(TestCase):
#     def test_form_with_valid_data(self):
#         form = TaskForm(data={"title":"test form", "description":"testing", "is_done":True})
#         self.assertTrue(form.is_valid())
                        
#     def test_form_with_no_valid_data(self):
#         form = TaskForm(data={})
#         self.assertFalse(form.is_valid())