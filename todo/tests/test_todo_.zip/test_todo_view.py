# from django.test import TestCase, Client
# from django.urls import reverse
# from accounts.models import User, Profile
# # Create your tests here.

# class TestTodoView(TestCase):
#     def setUp(self):
#         self.client = Client()
#         self.user = User.objects.create(email="test@gmail.com", password="qwe123QWE@")
#         self.profile = Profile.objects.create(
#             user=self.user,
#             first_name = 'test-first-name',
#             last_name = 'test-last-name',
#             description = 'test-tttttttttttttttttt',
#         )
    

#     def test_view_todo_logged_in_response(self):
#         self.client.force_login(self.user)
#         url = reverse('todo:task_list')
#         response = self.client.get(url)
#         self.assertEqual(response.status_code, 200)


#     def test_view_todo_anonymouse_response(self):
#         url = reverse('todo:task_list')
#         response = self.client.get(url)
#         self.assertEqual(response.status_code, 302)