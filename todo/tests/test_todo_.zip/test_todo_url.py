# from django.test import TestCase
# from django.urls import resolve, reverse
# from ..views import TaskListView
# # Create your tests here.

# class TestUrl(TestCase):

#     def test_todo_tasks_resolve(self):
#         url = reverse('todo:task_list')
#         self.assertEqual(resolve(url).func.view_class, TaskListView)
